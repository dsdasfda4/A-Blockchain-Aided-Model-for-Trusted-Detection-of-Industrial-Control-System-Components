//
// Created by wyd on 2024/5/31.
//
#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <mutex>
#include <sstream>


std::vector<std::string> split(const std::string& str, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(str);
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

// 函数来返回当前时间（以毫秒为单位）
long long getCurrentTimeMillis() {
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

int main()
{
    std::fstream ifs;
    ifs.open("/home/wyd/space/protocol.txt", std::ios::in);
    std::vector<std::string> data_vec;
    if (ifs.is_open())
    {
        std::string line;
        while (std::getline(ifs, line))
        {
            data_vec.emplace_back(line);
        }
        ifs.close();
    }

    std::mutex mutex;

    // 获取开始时间
    long long startTimeMillis = getCurrentTimeMillis();

    std::vector<std::thread> thread_vec;

    for (int i = 0; i < 8; i++)
    {
        thread_vec.emplace_back(std::thread([&data_vec, &mutex](){
            while (true)
            {
                mutex.lock();
                if (data_vec.empty())
                {
                    mutex.unlock();
                    break;
                }
                else
                {
                    std::string data_str = data_vec.back();
                    data_vec.pop_back();
                    mutex.unlock();

                    std::vector<std::string> parts = split(data_str, '.');

                    std::string predecessor = parts[0];
                    std::string subscript1 = parts[1];
                    std::string current = parts[2];
                    std::string subscript2 = parts[3];
                    std::string product = parts[4];
                    std::string assembly = parts[5];
                    std::string subscript3 = parts[6];
                    std::string subscript4 = parts[7];
                    std::string hash = parts[8];
                    std::string cache_time = parts[9];
                    std::string accurate_time = parts[10];
                    std::string detection = parts[11];
                    std::string quote = parts[12];
                }
            }
        }));
    }

    for (int i = 0; i < thread_vec.size(); i++)
    {
        if (thread_vec[i].joinable())
            thread_vec[i].join();
    }

    // 获取结束时间
    long long endTimeMillis = getCurrentTimeMillis();

    // 计算时间差
    long long timeDifferenceMillis = endTimeMillis - startTimeMillis;

    // 输出结果
    std::cout << "Time taken: " << timeDifferenceMillis << " (milliseconds)" << std::endl;

    return 0;
}
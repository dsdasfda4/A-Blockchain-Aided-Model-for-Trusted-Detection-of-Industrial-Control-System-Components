#include <iostream>
#include <fstream>

#include <string>
#include <random>
#include <ctime>

// 生成随机字符的函数
char getRandomChar() {
    const std::string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, chars.size() - 1);
    return chars[dis(gen)];
}

char getRandomNum() {
    const std::string chars = "0123456789";
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, chars.size() - 1);
    return chars[dis(gen)];
}

// 生成随机字符串的函数
std::string generateRandomString(int length) {
    std::string result;
    for (int i = 0; i < length; ++i) {
        result += getRandomChar();
    }
    return result;
}

std::string generateRandomNum(int length) {
    std::string result;
    for (int i = 0; i < length; ++i) {
        result += getRandomNum();
    }
    return result;
}

int main()
{
    // 初始化随机数生成器的种子
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    std::ofstream ofs;
    ofs.open("/home/wyd/space/protocol.txt", std::ios::out | std::ios::app);
    if (ofs.is_open())
    {
        for (int i = 0; i < 20000; i++)
        {
            // 生成一个长度为34的随机字符串
            std::string predecessor = generateRandomString(34);
            std::string subscript1 = generateRandomNum(1);
            std::string current = generateRandomString(34);
            std::string subscript2 = generateRandomNum(1);
            std::string product = generateRandomString(16);
            std::string assembly = generateRandomString(16);
            std::string subscript3 = generateRandomNum(2);
            std::string subscript4 = generateRandomNum(2);
            std::string hash = generateRandomString(16);
            std::string cache_time = generateRandomNum(2);
            std::string accurate_time = generateRandomNum(14);
            std::string detection = generateRandomString(34);
            std::string quote = generateRandomString(34);

            std::string all_str = predecessor.append(".").append(subscript1).append(".").append(current).append(".").append(subscript2).append(".").append(product)
                                    .append(".").append(assembly).append(".").append(subscript3).append(".").append(subscript4).append(".").append(hash).append(".")
                                    .append(cache_time).append(".").append(accurate_time).append(".").append(detection).append(".").append(quote);

            ofs << all_str << "\n";
        }
        ofs.close();
    }
    return 0;
}

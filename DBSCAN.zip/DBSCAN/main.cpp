﻿#include "cluster_analysis.h"
#include <cstdio>

using namespace std;

int main()
{
    ClusterAnalysis myClusterAnalysis;                        //聚类算法对象声明
    myClusterAnalysis.Init("D:\\test\\示例1.2(1).txt", 1,5);        //算法初始化操作，指定半径为15，领域内最小数据点个数为3，（在程序中已指定数据维度为2）
    myClusterAnalysis.DoDBSCANRecursive();                    //执行聚类算法
    myClusterAnalysis.WriteToFile("D:\\test\\XYResult.txt");//写执行后的结果写入文件

    return 0;            //返回
}